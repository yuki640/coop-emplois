\$compiler\_class {#variable.compiler.class}
=================

Specifies the name of the compiler class that Smarty will use to compile
the templates. The default is \'Smarty\_Compiler\'. For advanced users
only.
